//
//  QuestionsService.swift
//  1. domaca zadaca
//
//  Created by matej vagic on 05/04/2019.
//  Copyright © 2019 matej vagic. All rights reserved.
//

import Foundation


class Question{
    let question: String
    let answers: [String]
    let correct_answer:Int
    let id: Int
    
    init(question: String, correctAnswer: Int, answers:[String], correct_answer: Int,id: Int ){
        self.answers=answers
        self.question = question
        self.correct_answer = correct_answer
        self.id = id
        
        
    }
}
