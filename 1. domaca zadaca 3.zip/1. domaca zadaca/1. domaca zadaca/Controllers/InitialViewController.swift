//
//  InitialViewController.swift
//  1. domaca zadaca
//
//  Created by matej vagic on 05/04/2019.
//  Copyright © 2019 matej vagic. All rights reserved.
//

import UIKit

class InitialViewController: UIViewController {

    
    
    
    
    @IBOutlet weak var dohvati_button: UIButton!
    @IBOutlet weak var funFactLabel: UILabel!
    @IBOutlet weak var errorFetching: UILabel!
    @IBOutlet weak var quizTitle: UILabel!
    @IBOutlet weak var quizImage: UIImageView!
    @IBOutlet weak var questionViewContainer: UIView!
    
    

    var chosen_quiz:Quiz?
    var customView:QuestionView? = nil
    
    
    
    @IBAction func button_tapped(_ sender: UIButton) {
//        pricekat da zavrsi fetchanje kviza
        fetchQuiz{ (success) -> Void in
            if success! {
                // do second task if success
                self.addCustomView()
            }
            }
        
    }
    
    
    
    
    
    
    func fetchQuiz(completion: @escaping ((Bool?) -> Void)){
        
        
        let urlString = "https://iosquiz.herokuapp.com/api/quizzes"
        
        let quizService = QuizService()
        
        
        quizService.fetchQuiz(urlString: urlString) { (quiz) in

            DispatchQueue.main.async {
                if  quiz == nil {
                    self.error_message(string: "ERROR FETCHING")
                }
                else{
                    self.funFactLabel.text = "Broj NBA u kvizu \(Quizzes.noNBA)"
                    self.funFactLabel.isHidden = false
                    self.errorFetching.isHidden = true
                }
                
                if quiz?.quizzes.count == nil{
                    return
                }
                
                let rand = Int.random(in: 0...((quiz?.quizzes.count)! - 1))
                
                
                self.chosen_quiz = quiz?.quizzes[rand]
                
                completion(true)
                let category = (self.chosen_quiz?.category)!
                
                //postavlja sliku
                if self.chosen_quiz?.image != nil{
                    
                    self.quizImage.image = self.chosen_quiz?.image
                    if category == "SPORTS"{
                        self.quizImage.backgroundColor = UIColor(displayP3Red: 0.5, green: 0.5, blue: 0.5, alpha: 0.5)
                    }else{
                        self.quizImage.backgroundColor = UIColor(displayP3Red: 0.3, green: 0.2, blue: 0.9, alpha: 0.5)
                    }
                }
                
                self.quizTitle.text = category
                if category == "SPORTS"{
                    self.quizTitle.backgroundColor = UIColor(displayP3Red: 1, green: 0.5, blue: 0.5, alpha: 0.5)
                }else{
                    self.quizTitle.backgroundColor = UIColor(displayP3Red: 0.3, green: 0.2, blue: 0.9, alpha: 0.5)
                }
                
                
                
                
                
                
                
                
                
                
                
                
                
            }
        }
        
    }
    
    
    
    
    
    
    func addCustomView(){
        guard let quiz = self.chosen_quiz else{
            
            return
        }
        self.customView?.removeFromSuperview()
        self.customView = QuestionView(frame: CGRect(origin: CGPoint(x: 10, y: 10), size: CGSize(width: 300, height: 300)), quiz: quiz)
        
        self.customView?.isUserInteractionEnabled = true
        self.customView?.isMultipleTouchEnabled = true
        questionViewContainer.addSubview((self.customView)!)
        
        

        

    }

    
    func error_message(string: String){
        self.errorFetching.text = string
        self.errorFetching.isHidden = false
        self.funFactLabel.isHidden = true
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.dohvati_button.addTarget(self, action: #selector(InitialViewController.test), for: UIControl.Event.touchUpInside)
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "background")!)
        self.funFactLabel.backgroundColor = UIColor(displayP3Red: 0.3, green: 0.8, blue: 1, alpha: 0.5)

        self.errorFetching.isHidden = true
        self.funFactLabel.isHidden = true
        self.quizImage.isHidden = true
        self.quizTitle.layer.cornerRadius = 10
        self.dohvati_button.layer.cornerRadius = 10
        self.quizTitle.layer.cornerRadius = 10
        self.funFactLabel.layer.cornerRadius = 10
        
        
        
        
    }
    @objc func test() {
        
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
