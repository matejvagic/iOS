//
//  QuizService.swift
//  1. domaca zadaca
//
//  Created by matej vagic on 05/04/2019.
//  Copyright © 2019 matej vagic. All rights reserved.
//

import Foundation


class QuizService {
    func fetchQuiz(urlString: String, completion: @escaping ((Quizzes?) -> Void)) {
        if let url = URL(string: urlString) {
            let request = URLRequest(url: url)
            // URLRequest izmedu ostalog ima HTTP header-e
            
            let dataTask = URLSession.shared.dataTask(with: request) { (data, response, error) in
                if let data = data {
                    
                    
                    do {
                        
                        let json = try JSONSerialization.jsonObject(with: data, options: [])
                        
                        let quizzes = Quizzes(json: json)
                        
                        completion(quizzes)
                        
                        
                    } catch {
                        completion(nil)
                    }
                    
                    
                } else {
                    completion(nil)
                }
            }
            dataTask.resume()
        } else {
            completion(nil)
            
        }
        
    }
    
}
