//
//  Quiz.swift
//  1. domaca zadaca
//
//  Created by matej vagic on 05/04/2019.
//  Copyright © 2019 matej vagic. All rights reserved.
//

import Foundation
import UIKit
//promijeniti u Quizzes

class Quizzes{
    var quizzes: [Quiz?] = []
    static var noNBA: Int = 0
    static var no: Int = 1
    
    init?(json: Any) {
        
        
        Quizzes.no -= 1
        if let jsonDict = json as? [String: Any],
            let ids = jsonDict["quizzes"] as? NSArray
             {
                
                for i in ids{
                    
                    
                    let obj = i as? [String:Any]
                    if let category = obj?["category"] as? String,
                        let id = obj?["id"] as? Int,
                        let questions = obj?["questions"] as? NSArray,
                        let level = obj?["level"] as? Int
                        {
                            let description = obj?["description"] as? String?
                            
                            let image = obj?["image"] as? UIImage?
                            //stvaranje objekta quizzes
                            let quiz = Quiz(category: category, id: id, description: description ?? nil, image: image ?? nil, level: level, questions: [])
                            
                            
                            //parsiranje pitanja
                            for i in questions{
                                if let questionMap = i as? [String:Any],
                                    let question = questionMap["question"] as? String,
                                    let id = questionMap["id"] as? Int,
                                    let answers = questionMap["answers"] as? [String],
                                    let correct_answer = questionMap["correct_answer"] as? Int
                                    {
                                        let questionObj = Question(question: question, correctAnswer: correct_answer, answers: answers, correct_answer: correct_answer, id: id)
                                        if question.contains("NBA"){
                                            Quizzes.fnoNBA()
                                        }
                                        quiz?.questions.append(questionObj)
                                        
                                        
                                }
                                else{
                                    
                                    return nil
                                    
                                }
                            }
                            self.quizzes.append(quiz)
                            
                        
                    }
                    else {
                        
                        return nil
                    }
                    
                    
                }
                
                
            // ako je sve uspjesno castano, tada s dohvacenim vrijednostima mozemo inicijalizirati varijable razreda
           
        } else {
            
            // u slucaju da je nesto poslo krivo, nekakav kljuc je drugaciji ili je tip kriv, vratimo nil
            return nil
            
        }
        
        
        
    }
    
    class func fnoNBA(){
        if Quizzes.no == 0{
        
            noNBA+=1
        }
        
    }
}
