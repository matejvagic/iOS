//
//  Quizzes.swift
//  1. domaca zadaca
//
//  Created by matej vagic on 05/04/2019.
//  Copyright © 2019 matej vagic. All rights reserved.
//

import Foundation
import UIKit

class Quiz{
    let category: String
    let description: String?
    let id: Int
    let image: UIImage?
    let level: Int
    
    var questions: [Question?]
    
    init?(category:String, id: Int, description: String?, image: UIImage?, level:Int, questions: [Question?]){
        self.category = category
        self.id = id
        self.level = level
        self.description = description
        self.questions = questions
        self.image = image
        
    }
}
