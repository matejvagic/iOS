//
//  QuestionView.swift
//  1. domaca zadaca
//
//  Created by matej vagic on 07/04/2019.
//  Copyright © 2019 matej vagic. All rights reserved.
//

import Foundation
import UIKit

class QuestionView: UIView{
    
    var naziv_kviza: UILabel? = nil
    var quiz: Quiz?
    var button0: UIButton? = nil
    var button1: UIButton? = nil
    var button2: UIButton? = nil
    var button3: UIButton? = nil
    var brojac:Int = 0
    var correct_answer:Int? = nil
    
    // Slijede nam dva init-a, prvi se poziva kada inicijaliziramo CustomView iz koda, a drugi kada ga inicijaliziramo iz .xib datoteke
    
    // Ovaj init prima pravokutnik u kojem ce se ovaj CustomView iscrtati
    init(frame: CGRect, quiz: Quiz) {
        
        self.quiz = quiz
        
        brojac = (self.quiz?.questions.count)!
        super.init(frame: frame)
        self.isOpaque = false
        self.backgroundColor = UIColor(white: 0, alpha: 0)
        super.isUserInteractionEnabled = true
        super.isMultipleTouchEnabled = true
        self.isUserInteractionEnabled = true
        // ovdje u init-u inicijaliziramo i konfiguriramo subview-ove CustomView-a
        naziv_kviza = UILabel(frame: CGRect(origin: CGPoint(x: 40, y: 10), size: CGSize(width: 280, height: 70)))
        
        self.button0 = UIButton(frame: CGRect(origin: CGPoint(x: 40, y: 100), size: CGSize(width: 280, height: 20)))
        self.button1 = UIButton(frame: CGRect(origin: CGPoint(x: 40, y: 140), size: CGSize(width: 280, height: 20)))
        self.button2 = UIButton(frame: CGRect(origin: CGPoint(x: 40, y: 180), size: CGSize(width: 280, height: 20)))
        self.button3 = UIButton(frame: CGRect(origin: CGPoint(x: 40, y: 220), size: CGSize(width: 280, height: 20)))
        
        self.button0?.layer.cornerRadius = 10
        self.button1?.layer.cornerRadius = 10
        self.button2?.layer.cornerRadius = 10
        self.button3?.layer.cornerRadius = 10
        self.naziv_kviza?.layer.cornerRadius = 10
        self.naziv_kviza?.font = UIFont(name: "HelveticaNeue", size: 15)
        
        
        self.button0?.tag = 0
        self.button1?.tag = 1
        self.button2?.tag = 2
        self.button3?.tag = 3
        
        
        
        
        
        
        self.button0?.addTarget(self, action: #selector(self.button_tapped), for: UIControl.Event.touchUpInside)
        self.button1?.addTarget(self, action: #selector(self.button_tapped), for: UIControl.Event.touchUpInside)
        self.button2?.addTarget(self, action: #selector(self.button_tapped), for: UIControl.Event.touchUpInside)
        self.button3?.addTarget(self, action: #selector(self.button_tapped), for: UIControl.Event.touchUpInside)
        
        
        self.button0?.isUserInteractionEnabled = true
        self.button1?.isUserInteractionEnabled = true
        self.button2?.isUserInteractionEnabled = true
        self.button3?.isUserInteractionEnabled = true
        
        self.button0?.isEnabled = true
        self.button1?.isEnabled = true
        self.button2?.isEnabled = true
        self.button3?.isEnabled = true
        
//        self.button0?.showsTouchWhenHighlighted = true
//        self.button1?.showsTouchWhenHighlighted = true
//        self.button2?.showsTouchWhenHighlighted = true
//        self.button3?.showsTouchWhenHighlighted = true
        
        
        
        
        

        
        
        naziv_kviza?.backgroundColor = UIColor(displayP3Red: 0.3, green: 0.8, blue: 1, alpha: 0.5)
        self.button0?.backgroundColor = UIColor(displayP3Red: 1, green: 0.5, blue: 0.5, alpha: 0.5)
        self.button1?.backgroundColor = UIColor(displayP3Red: 1, green: 0.5, blue: 0.5, alpha: 0.5)
        self.button2?.backgroundColor = UIColor(displayP3Red: 1, green: 0.5, blue: 0.5, alpha: 0.5)
        self.button3?.backgroundColor = UIColor(displayP3Red: 1, green: 0.5, blue: 0.5, alpha: 0.5)
        
        
        if let label = naziv_kviza,
            let button0 = self.button0,
            let button1 = self.button1,
            let button2 = self.button2,
            let button3 = self.button3
        
            {
                self.addSubview(label)
                self.addSubview(button0)
                self.addSubview(button1)
                self.addSubview(button2)
                self.addSubview(button3)
                
                
        }
        self.naziv_kviza?.lineBreakMode = .byWordWrapping
        self.naziv_kviza?.numberOfLines = 2
        self.naziv_kviza?.textAlignment = .center
        
        
        
        changeQuestions(button0!)
    }
    
    // Ovaj init se poziva kada se CustomView inicijalizira iz .xib datoteke
    required init?(coder aDecoder: NSCoder, quiz:Quiz) {
        
        self.quiz = quiz

        self.button0 = UIButton(frame: CGRect(origin: CGPoint(x: 20, y: 300), size: CGSize(width: 200, height: 20)))
        self.button1 = UIButton(frame: CGRect(origin: CGPoint(x: 20, y: 500), size: CGSize(width: 200, height: 20)))
        self.button2 = UIButton(frame: CGRect(origin: CGPoint(x: 20, y: 700), size: CGSize(width: 200, height: 20)))
        self.button3 = UIButton(frame: CGRect(origin: CGPoint(x: 20, y: 1000), size: CGSize(width: 200, height: 20)))
        
        super.init(coder: aDecoder)
        
        self.button1?.addTarget(self, action: #selector(button_tapped), for: UIControl.Event.touchUpInside)
        naziv_kviza?.text = quiz.questions[0]?.question
        self.naziv_kviza?.lineBreakMode = .byWordWrapping
        self.naziv_kviza?.numberOfLines = 0
        self.naziv_kviza?.textAlignment = .center
        
        

        
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
    }
    
    
    
//    func chosen(quiz:Quiz){
//        for i in 0...(quiz.questions.count - 1){
//            label?.text = quiz.questions[i]?.question
//
//        }
//    }
    
    @objc func button_tapped(sender: UIButton!){
        
        
        
        change_color(sender, completion: { (success) -> Void in
            if success! {
                // do second task if success
                self.changeQuestions(sender)
            }
        })
        
       
        
        
        
        
    }
    
    func change_color(_ sender: UIButton, completion: @escaping ((Bool?) -> Void)){
        if sender.tag == self.correct_answer! {
            sender.backgroundColor = UIColor.green
            self.isUserInteractionEnabled = false
            
        } else{
            sender.backgroundColor = UIColor.red
            self.isUserInteractionEnabled = false
            
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) { // Change `2.0` to the desired number of seconds.
            // Code you want to be delayed
            sender.backgroundColor = UIColor(displayP3Red: 1, green: 0.5, blue: 0.5, alpha: 0.5)
            self.isUserInteractionEnabled = true

            completion(true)
        }
        
        
        
        
        
        
        
        
        
        
    }
    
    
    
    
    
    func changeQuestions(_ sender:UIButton){
        if brojac <= 1{
            self.naziv_kviza?.text = "NO MORE QUIZ"
            self.button0?.setTitle("", for: UIControl.State.normal)
            self.button1?.setTitle("", for: UIControl.State.normal)
            self.button2?.setTitle("", for: UIControl.State.normal)
            self.button3?.setTitle("", for: UIControl.State.normal)
            
            self.button0?.isUserInteractionEnabled = false
            self.button1?.isUserInteractionEnabled = false
            self.button2?.isUserInteractionEnabled = false
            self.button3?.isUserInteractionEnabled = false
            
            
            return
        }
        
        brojac-=1
        self.naziv_kviza?.text = self.quiz?.questions[brojac - 1]?.question
        self.naziv_kviza?.adjustsFontSizeToFitWidth = false
        self.correct_answer = self.quiz?.questions[brojac - 1]?.correct_answer
        self.button0?.setTitle(self.quiz?.questions[brojac - 1]?.answers[0], for: UIControl.State.normal)
        self.button1?.setTitle(self.quiz?.questions[brojac - 1]?.answers[1], for: UIControl.State.normal)
        self.button2?.setTitle(self.quiz?.questions[brojac - 1]?.answers[2], for: UIControl.State.normal)
        self.button3?.setTitle(self.quiz?.questions[brojac - 1]?.answers[3], for: UIControl.State.normal)
        
        
        
        
        
        
        
        
        
//        self.button0?.titleLabel?.adjustsFontSizeToFitWidth = true
//        self.button1?.titleLabel?.adjustsFontSizeToFitWidth = true
//        self.button2?.titleLabel?.adjustsFontSizeToFitWidth = true
//        self.button3?.titleLabel?.adjustsFontSizeToFitWidth = true
        
        
        
    }
}
